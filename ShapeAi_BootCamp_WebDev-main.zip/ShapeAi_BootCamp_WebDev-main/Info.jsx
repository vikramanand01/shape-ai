import React from  "react";
function Info(){
  return(
    <div className="note">
      <h1 >JavaScript and ReactJs</h1>
      <p >A basic web development bootcamp using JavaScript and ReactJs.
        Starts on 30th June,5:30PM IST. Duration - 7days. 
      </p>
    </div>
    );
}
export default Info;